# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: Fixtures\fixture.spec.ts >> page fixture
- Location: tests\Fixtures\fixture.spec.ts:5:1

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.fill: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByPlaceholder('placeholder')

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - generic [ref=e4]: Swag Labs
  - main [ref=e5]:
    - form "Login" [ref=e9]:
      - textbox "Username" [active] [ref=e11]: Hello
      - textbox "Password" [ref=e13]
      - button "Login" [ref=e15] [cursor=pointer]
    - generic [ref=e17]:
      - generic [ref=e18]:
        - heading "Accepted usernames are:" [level=4] [ref=e19]
        - text: standard_userlocked_out_userproblem_userperformance_glitch_usererror_uservisual_user
      - generic [ref=e20]:
        - heading "Password for all users:" [level=4] [ref=e21]
        - text: secret_sauce
```

# Test source

```ts
  1  | import {test} from "@playwright/test"
  2  | 
  3  | // ! page Fixture
  4  | 
  5  | test("page fixture", async({page,browserName})=>{
  6  |   await page.goto('https://www.saucedemo.com/')
  7  |   await page.getByPlaceholder("Username").fill("Hello")
> 8  |   await page.getByPlaceholder("placeholder").fill("Hii")
     |                                              ^ Error: locator.fill: Test timeout of 30000ms exceeded.
  9  |   await page.getByText("Login").click()
  10 |   await page.waitForTimeout(3000)
  11 | })
  12 | 
  13 | // ! context Fixture
  14 | // test("context fixture ", async({context})=>{
  15 | //   let p1= await context.newPage();
  16 | //   let p2= await context.newPage()
  17 |   
  18 | //   await p1.goto("https://www.youtube.com/")
  19 | //   await p2.goto("https://www.myntra.com/")
  20 | // })
```